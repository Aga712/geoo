/* Plik 'setup.js' zawiera zbiór niezbędnych funkcji
 do implementowania algorytmów geomietrii obliczniowej.
 Zawiera między innymi funkcję losującą zestaw punktów,
 funkcje sortujące, funkcje rysujące otoczkę wypukłą,
 funkcję sprawdzającą lewo lub prawo skręt punktu względem
 poprzedniego i natepęgo punkty (funkcja przyda się do
 implementacji algortymu Gragama) i inne.
 */

//poniżej przygotowanie półtna dla algortymu Grahama
var cvGA = document.getElementById('canvasGraham'); //do zmiennaj cvGA przypisujemy elemant canvas
var ctxGA = cvGA.getContext('2d'); //oznaczamy kontext canvas jako dwuwymiarowy
var cvGAWidth = cvGA.width; // pobieramy szerokość canvasu
var cvGAHeight = cvGA.height; // pobieramy wysokość canvasu

const points = []; // lista punktów wylosowanych, na razie pusta
const pointsJarvis = [];  //lista punktów dla algoytmu Jarvisa, będzie zawierać ten sam zbór pkt co 'points' jednak inaczej posortowny
const grahamHull = []; // lista bedzie zawierać punkty otoczki obliczonej algrotymem Grahama

const quickHullUp = []
const quickHullDown = []
const jarvisHull = []

let lowestPoint; // ta zmienna będzie punktem o najmniejszej wartości y czyli środkiem układu współrzędnych biegunowych
let current;
let next;

let leftPoint;
let rightPoint;

let currentJarvis;
let nextJarvis;


//funkcja setup ma za zadanie przygotować listę losowych punktów
//oraz przygotować startowe punkty dla każdego z algortymów
function setup() {

    drawPoints(35); //lostujemy punkty korzystając z naszej funkcji

    

    points.sort(function(a, b) {                        //sortujemy punkty stabilnym sortowaniem z wykorzytaniem naszej funkcji sortującej
                                                        //sortujemy względem x rosnąco, jęśli x równe to względem y malejąco
        return sortByXAscending(a, b) || b.y - a.y;
    });

    leftPoint = points[0];                              //wyznaczmy punkt najbardzej po lewej i po prawej
    rightPoint = points[points.length - 1];
    
    currentJarvis = leftPoint.duplicate();              //kopiujemy punkt z wykorzystaniem medoty klasy punkt z biblioteki podstwowej

    nextJarvis = points[1];
    jarvisHull.push(leftPoint);

    for(let p of points){
        pointsJarvis.push(p);
    }
 
    points.sort(function(a, b) {
        return sortByYAscending(a,b) || a.x - b.x;
    });

    lowestPoint = points[0];  //wyznaczamy najniższy punkt (punkt ten będzie środkiem układu biegunowego - potrzebne do algortymu Grahama)

    points.sort(function(a, b) {
        return sortByAngle(a, b) || a.x - b.x;      // sortujemy punkty względem kąta w stosunku do środka układu biegunowego (Graham)
    });
    
    current = lowestPoint.duplicate();                                    
    grahamHull.push(current);

    next = points[1];
    
    //przgotowanie pod quickhull
    quickHullUp.push(leftPoint);
    quickHullUp.push(rightPoint);

    quickHullDown.push(rightPoint);
    quickHullDown.push(leftPoint);

}

setup(); // wywołujemy setup


/* Funkcja 'drawPoints' losuje zestaw punktów.
    Na wejściu podajemy ilość punktów do wylosowania
    oraz szerokość i wysokość płótna (konieczne, 
    aby punkty zmieściły się na planszy).
 */

function drawPoints(amount){
    var loso=function(a,b){return Math.floor(Math.random()*(b-a)+a);} //losowanie punktów
    
    for (let i = 0; i < amount; i++) {
        points.push(                          
        new Point(                //każdy punkt jest obiektem klasy Point z bilioteki podstawowej
            loso(20,cvGAWidth-20),
            loso(20,cvGAHeight-20)
        ));
    }

    return points;
}

/* Poniżej zestaw funkcji sortujących.
    Funkcję zostały stworzone w celu stabilnego 
    sortowania.
 */
function sortByXAscending(a, b) {
    return a.x - b.x;
}

function sortByAngle(a, b) {
    return  b.angleTo(lowestPoint)- a.angleTo(lowestPoint)
}

function sortByYAscending(a, b) {
    return b.y - a.y;
}

function sortByXDescending(a, b) {
    return b.x - a.x;
}

/* Funkcja 'clearCanvas' służy od czyszczenia płótna.
(funkcja będzie przydatna do towrzenia animacji).
Na wejściu podajemy kontekst, czyli które półtno
ma zostać wyzerowane jego szerokość i wysokość.
 */
function clearCanvas(context, width, height){
    context.clearRect(0, 0, width, height);
}

/* Funkcja 'drawHull' służy do rysowania 
otoczki. Na wejściu podajemy zestaw punktów
tworzących otoczkę (punkty muszą być odpowiednio
posortowane), kolor w jakim otoczka ma zostać narysowana,
oraz płótno.
 */
function drawHull(vertices, color, context){

    context.strokeStyle = color;             
    context.beginPath();
    context.moveTo(vertices[0].x, vertices[0].y);
    for(let i = 1; i < vertices.length; i++){
        context.lineTo(vertices[i].x, vertices[i].y);
    }
    context.stroke();
    
}

/* Funkcja 'drawHullUpDown' służy do rysowania 
otoczki w szczególnym przypadku 
algorytmu takiego jak QuickHull, gdzie
należy połączyć otoczkę dolną z górną.
Na wejściu podajemy zestaw punktów
tworzących otoczkę górną oraz dolną(punkty muszą być odpowiednio
posortowane), kolor w jakim otoczka ma zostać narysowana,
oraz płótno.
 */
function drawHullUpAndDown(hullUp, hullDown, color, context){

    context.strokeStyle = color;              
    context.beginPath();
    context.moveTo(hullUp[0].x, hullUp[0].y);
        for(let i = 1; i < hullUp.length; i++){
         context.lineTo(hullUp[i].x, hullUp[i].y);
        }
        for(let i = 1; i < hullDown.length; i++){
           context.lineTo(hullDown[i].x, hullDown[i].y);
        }
        context.closePath();
        context.stroke();
}

/* Funkcja 'drawText' rysuje na płótnie
podany na wejściu text. Na wejściu podajemy
text jaki ma zostać napisny, półtno na którym
text ma zostać napisany oraz wysokość i szerokość
płótna oraz rodzaj i wielkość czcionki
 */
function drawText(text, context, width, height, font){
    context.font = font;
    context.fillText(text, width/2, height-5);
}

/* Funkcja 'findFarthestPointOnSide' 
znajuję najbardziej oddalony punkt (z 
zestawu wylosowanych punktów) od odcinka
(podanego na wejściu) po wybranej stronie
odcinka (stronę również podajemy na wejściu
w formie string: above lub below). Funkcja
zwraca najbardziej oddalony punkt (obiekt Point)
po wybranej stronie.
 */
function findFarthestPointOnSide(segment, side){

    let pointsOnSide = []

    if(side == "above"){

        for(let p of points){

            if(p!=segment.getA() && p!= segment.getB()){

                if(segment.createLine().isPointAbove(p)){

                    p.draw("yellow", ctxQH);
                    pointsOnSide.push(p);

                }
            }
        }
    
        if(pointsOnSide.length==0){
           
            return 0;
    
        }else{
        
            pointsOnSide.sort((a, b) => segment.distanceToPoint(b)- segment.distanceToPoint(a));
              
            return pointsOnSide[0];
        }

    }

    if(side == "below"){

        for(let p of points){

            if(p!=segment.getA() && p!= segment.getB()){

                if(segment.createLine().isPointBelow(p)){

                    p.draw("yellow", ctxQH);
                    pointsOnSide.push(p);

                }
            }
        }
    
        if(pointsOnSide.length==0){
           
            return 0;
    
        }else{
        
            pointsOnSide.sort((a, b) => segment.distanceToPoint(b)- segment.distanceToPoint(a));
              
            return pointsOnSide[0];
        }

    }

  }

  /*
Funkcja checkPoints przyjmuje na wejściu 3 punkty. Sprawdza czy punkt p1 wykonuje prawo lub lewo skręt
zwraca prawdę lub fałsz (Boolean). Potrzebna do algortymu Grahama.
*/
function checkPoints (p0, p1, p2) {

    var diffAngle;
    var cwAngle = -1*p1.angleTo(p0);
    var ccwAngle = -1*p2.angleTo(p0);
    
  
    if (cwAngle > ccwAngle) {
  
        diffAngle = cwAngle - ccwAngle;
  
        return !(diffAngle > 180);
  
    } else if (cwAngle < ccwAngle) {
  
        diffAngle = ccwAngle - cwAngle;
  
        return (diffAngle > 180);
  
    }
  
    return true;
  }