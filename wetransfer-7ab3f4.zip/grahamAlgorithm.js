let index = 2;
let counter = 1;


//funkcja grahamAlgorithm korzysta z algorytmu Grahama, aby wyznaczyć otoczkę wypukłą dla losowego zbioru
//punktów. Funkcja jednocześnie odpowiada za wizualizację działania algorytmu

function grahamAlgorithm() {

  if(counter % 15 == 0){    //wykonujemy funkcję co 10-tą klatkę aby spowolnić wizualizację algorytmu
    
    clearCanvas(ctxGA, cvGAWidth, cvGAHeight);    //czyszczenie płaszczyzny przed każdą klatką za pomocą funkcji z setup.js

    points.forEach(function(a){a.draw("black", ctxGA)}); // kożystamy z funkcji draw z biblioteki podstawowej aby narysować wszystkie punkty
    
    drawHull(grahamHull, "green", ctxGA); //kożystamy z funkcji z biblioteki podstawowej, aby zaaktualizować otoczkę co każdą klatkę

    grahamHull.forEach(function(a){a.draw("green", ctxGA)});   //punkty w otoczce rysujemy na zielono
    
    next.draw("yellow", ctxGA);    //punkt sprawdzany rysujemy na żołto

    current.createSegment(next).draw("green", ctxGA);// rysujemy sprawdony odcinek na zielono

    let thirdVertex = points[index]; 

    next.createSegment(thirdVertex).draw("yellow", ctxGA); //rysujemy sprawdzany odcinek na żółto
  
    if(checkPoints(current, next, thirdVertex)){  //sprawdzamy czy punk next skręca w prawo lub w lewo korzystając z funkcji z pliku steup.js

      next.draw("red", ctxGA);                         //jeśli w prawo to cofamy pozycję
    
      if(grahamHull.length != 1){
      next = current
      current = grahamHull[grahamHull.length - 2];
      grahamHull.splice(grahamHull.length-1, 1);
      }else{
        next = thirdVertex;
        index++;
      }

    }else{              //jeśli w lewo to przechodzimy do następnego punktu

      grahamHull.push(next)
      current = next;
      next = thirdVertex;
      index = index + 1;

    }

    if(points.length == index){
      
      index =0;
    
    }

    if (thirdVertex.equals(lowestPoint)) {
      //jeśli sprawdzany punkt jest równy punktowi będącemy środkiem układu współ. bieg.
      // to tworzymy obiekt klasy Polygon z biblioteki podstawowej i rysujemy go na płaszczyźnie                             
      // wykorzystując do tego metodę draw również z naszej biblioteki
      
      current.draw("green", ctxGA);       

      polygon = new Polygon(grahamHull);

      polygon.draw("green", ctxGA);
    
      drawText("Graham Algorithm is finished !", ctxGA, cvGAWidth, cvGAHeight, "12px Arial");
   

      console.log("graham algorytm")
      console.log(grahamHull);
      

    }else{

      requestAnimationFrame(grahamAlgorithm); //jeśli nie jest równy to kontynuujemy animacje

    }
  
  }else{requestAnimationFrame(grahamAlgorithm);}

  counter++;
}

grahamAlgorithm();

