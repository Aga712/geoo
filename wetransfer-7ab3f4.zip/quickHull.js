//przygotowanie zmiennych potrzebnych do konfiguracji płótna dla quickhull
var cvQH = document.getElementById('canvasQuickHull'); //do zmiennaj cv przypisujemy elemant canvas
var ctxQH = cvQH.getContext('2d'); //oznaczamy kontext canvas jako dwuwymiarowy
var cvQHWidth = cvQH.width; // pobieramy szerokość canvasu
var cvQHHeight = cvQH.height; // pobieramy wysokość canvasu

let canMoveToBelow= false;
let frameRate = 1;
let quickIndex = 1;

function quickHull(){

    if(frameRate % 35 == 0){   // animację odtwarzamy co 35 klatkę aby ułatwić odbiór wizualizacji

        clearCanvas(ctxQH, cvQHWidth, cvQHHeight); // czyszczenie płótna przed rysowaniem (setup.js)
  
        points.forEach(function(a){a.draw("black" , ctxQH)});       //rysujemy punkty metodą draw z bib. pod.
                                                                            
        drawHullUpAndDown(quickHullUp, quickHullDown, "green", ctxQH);//akualizacjia otoczki co każdą klatkę (wykorzystanie funkcji z setup.js)

        quickHullUp.forEach(function(a){a.draw("green", ctxQH)});   //rysowanie otoczki górnej
        quickHullDown.forEach(function(a){a.draw("green", ctxQH)}); //rysowanie otoczki dolnej
  
        if(!canMoveToBelow){        // zaczynamy algorytm od otoczki górnej

            segment = new Segment(quickHullUp[quickIndex-1], quickHullUp[quickIndex]);

            let farthestPoint = findFarthestPointOnSide(segment, "above");   // korzystamy z funkcji (setup.js) aby znaleźć najbardziej oddalony punkt od odcinka

            if(farthestPoint != 0){                                        

                farthestPoint.draw("red", ctxQH);                   //najdalszy punkt rysujemy na czerwono

                quickHullUp.push(farthestPoint);                //dodajemy punkt do otoczki górnej

            }
            if(farthestPoint == 0){

                if(quickHullUp[quickIndex]==rightPoint){            // jeśli powyżej wszystkich odcinkó z otoczki górnej nie ma żadnego punktu
                    canMoveToBelow = true;                          // to możemy przejść do otoczki dolnej
                    quickIndex = 1;
                }else{
                    quickIndex++;
                }
            }
    
            for (var i=0; i<quickHullUp.length; i++)

                quickHullUp[i].index = i;
                quickHullUp.sort(function(a, b) {
                return sortByXAscending(a, b) || a.index - b.index;
                });
        }

        if(canMoveToBelow == true){                         // ten sam proces zachodzi dla otoczki dolnej jednak tym razem szykamy punktów poniżej odcinków
    
            segment = new Segment(quickHullDown[quickIndex-1], quickHullDown[quickIndex]);
        

            farthestPoint = findFarthestPointOnSide(segment, "below")

            if(farthestPoint != 0){
                farthestPoint.draw("red", ctxQH);
                quickHullDown.push(farthestPoint);
    
            }

            if(farthestPoint==0){

                if(quickHullDown[quickIndex].equals(leftPoint)){    // jeśli dotarliśmy do punktu startowego to znaczy że otoczka jest gotowa

                    for(let p of quickHullDown){
                        if(p != leftPoint && p != rightPoint){          //dodajemy otoczkę dolną do górnej
                            quickHullUp.push(p);
                        }
                    }
                    console.log("quickhull");
                    console.log(quickHullUp);

                    drawText("QuickHull is finished !", ctxQH, cvQHWidth, cvQHHeight, "12px Arial");    
                
                    var stopAnimation=true;     // jeśli dotarliśmy tutaj to przerywamy animacje
        
                }else{
                        
                    quickIndex++;
                
                }

            }
    
            for (var i=0; i<quickHullDown.length; i++){
                quickHullDown[i].index = i;
            }

            quickHullDown.sort(function(a, b) {                            //na koniec każdej klatki sortujemy odpowiednio punkty
                return sortByXDescending(a, b) || a.index - b.index;        //aby łatwiej było je narysować w następnej klatce
            });    
        }

        if(!stopAnimation)
            requestAnimationFrame(quickHull);
  
    }else{requestAnimationFrame(quickHull);}
  
    frameRate++;

}
  
quickHull();

